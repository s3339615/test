$(document).ready(function(){
    $('.carousel').carousel();
});
