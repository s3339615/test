<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Xin
 * Date: 24/09/2013
 * Time: 15:31
 * To change this template use File | Settings | File Templates.
 */
App::uses('AppModel', 'Model');

Class Cart extends AppModel{
    

}